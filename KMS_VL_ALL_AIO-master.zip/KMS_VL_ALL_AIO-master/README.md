# KMS_VL_ALL_AIO
Smart Activation Script

[![Release downloads](https://img.shields.io/github/downloads/abbodi1406/KMS_VL_ALL_AIO/total.svg)](https://GitHub.com/abbodi1406/KMS_VL_ALL_AIO/releases/)
